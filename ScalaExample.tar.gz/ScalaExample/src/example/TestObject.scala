package example

import java.io.BufferedReader
import java.io.FileReader
import java.io.IOException


object TestObject {

  def main(args: Array[String]) {
    
    
    	///home/hduser/workspace/Test/src
		var fr = new FileReader("../data.txt") //file path 
		var br = new BufferedReader(fr) //stream the file
		
		
		var data=br.readLine()
		
		while(  data !=null )
		{
		
			println(data)
			data=br.readLine()
		}
		
		  
		br.close()
		fr.close()
		
    
  }
 
  
}