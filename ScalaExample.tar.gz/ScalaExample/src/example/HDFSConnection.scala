package example

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import java.io.PrintWriter;

object HDFSConnection {

  
  def write(uri: String, filePath: String, data: Array[Byte]) = {
//      System.setProperty("HADOOP_USER_NAME", "Mariusz")
      val path = new Path(filePath)
      val conf = new Configuration()
      conf.set("fs.defaultFS", uri)
      val fs = FileSystem.get(conf)
      val os = fs.create(path)
      os.write(data)
      fs.close()
    }

  
  def main(args: Array[String]){
    
    write("hdfs://localhost:9870", "hdfs://localhost:9870/test/test.txt", "Hello World".getBytes)
    
    println("saved")
    
    
    
  }
}